"use client"

import { useState, useEffect } from "react"
import type { User } from "firebase/auth"
import type { UserProfile } from "@/lib/auth-service"
import { userService } from "@/lib/user-service"
import { Sidebar } from "./sidebar"
import { ChatWindow } from "./chat-window"

interface Props {
  currentUser: User
  currentUserProfile: UserProfile
  blockedUsers: Record<string, boolean>
}

export function ChatLayout({ currentUser, currentUserProfile, blockedUsers }: Props) {
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null)
  const [users, setUsers] = useState<Record<string, UserProfile>>({})
  const [searchResults, setSearchResults] = useState<UserProfile[]>([])
  const [searchTerm, setSearchTerm] = useState("")

  useEffect(() => {
    const unsubscribe = userService.onUsersChanged((usersData) => {
      setUsers(usersData)
    })

    return () => unsubscribe()
  }, [])

  const handleSearch = async (term: string) => {
    setSearchTerm(term)
    if (term.trim()) {
      const results = await userService.searchUsers(term)
      setSearchResults(results.filter((u) => u.uid !== currentUser.uid))
    } else {
      setSearchResults([])
    }
  }

  const otherUsers = Object.values(users)
    .filter((u) => u.uid !== currentUser.uid)
    .sort((a, b) => {
      const aBlocked = blockedUsers[a.uid] ? 1 : 0
      const bBlocked = blockedUsers[b.uid] ? 1 : 0
      return aBlocked - bBlocked
    })

  return (
    <div className="flex h-screen w-full overflow-hidden">
      {!selectedUser ? (
        <Sidebar
          currentUser={currentUserProfile}
          users={otherUsers}
          searchResults={searchResults}
          searchTerm={searchTerm}
          onSearch={handleSearch}
          selectedUser={selectedUser}
          onSelectUser={setSelectedUser}
          blockedUsers={blockedUsers}
          currentUserId={currentUser.uid}
        />
      ) : (
        <ChatWindow
          currentUser={currentUser}
          currentUserProfile={currentUserProfile}
          selectedUser={selectedUser}
          onBack={() => setSelectedUser(null)}
          blockedUsers={blockedUsers}
        />
      )}
    </div>
  )
}
