"use client"

import { useRouter } from "next/navigation"
import type { UserProfile } from "@/lib/auth-service"
import Link from "next/link"
import { useState } from "react"
import { authService } from "@/lib/auth-service"
import { chatService } from "@/lib/chat-service"
import { Settings, LogOut, Trash2 } from "lucide-react"

interface Props {
  currentUser: UserProfile
  users: UserProfile[]
  searchResults: UserProfile[]
  searchTerm: string
  onSearch: (term: string) => void
  selectedUser: UserProfile | null
  onSelectUser: (user: UserProfile) => void
  blockedUsers: Record<string, boolean>
  currentUserId: string
}

export function Sidebar({
  currentUser,
  users,
  searchResults,
  searchTerm,
  onSearch,
  selectedUser,
  onSelectUser,
  blockedUsers,
  currentUserId,
}: Props) {
  const router = useRouter()
  const [showMenu, setShowMenu] = useState(false)
  const [showDeleteChatsConfirm, setShowDeleteChatsConfirm] = useState(false)
  const [isDeleting, setIsDeleting] = useState(false)

  const handleLogout = async () => {
    await authService.logout()
    router.push("/")
  }

  const handleDeleteAllChats = async () => {
    setIsDeleting(true)
    try {
      await chatService.deleteAllChats(currentUserId)
      setShowDeleteChatsConfirm(false)
      router.refresh()
    } catch (error) {
      console.error("خطأ في حذف المحادثات:", error)
      alert("حدث خطأ في حذف المحادثات")
    } finally {
      setIsDeleting(false)
    }
  }

  const displayUsers = searchTerm ? searchResults : users

  return (
    <div className="w-full h-screen bg-white flex flex-col overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-gray-200 bg-gradient-to-r from-indigo-600 to-purple-600 text-white sticky top-0 z-20">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-2xl font-bold">ChatApp</h1>
          <div className="flex gap-2">
            <Link
              href="/profile"
              className="w-10 h-10 rounded-full bg-white text-indigo-600 flex items-center justify-center hover:shadow-lg transition font-bold flex-shrink-0"
            >
              <Settings size={20} />
            </Link>
            <button
              onClick={() => setShowMenu(!showMenu)}
              className="w-10 h-10 rounded-full bg-white text-indigo-600 flex items-center justify-center hover:shadow-lg transition font-bold flex-shrink-0"
            >
              {currentUser.avatar}
            </button>
          </div>
        </div>

        {/* Search - البحث فقط عن اسم المستخدم */}
        <input
          type="text"
          placeholder="ابحث عن اسم المستخدم..."
          value={searchTerm}
          onChange={(e) => onSearch(e.target.value)}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-indigo-600 bg-white text-gray-900 placeholder-gray-500"
        />

        {showMenu && (
          <div className="absolute left-4 mt-12 w-40 bg-white border border-gray-200 rounded-lg shadow-lg z-50 text-gray-900">
            <button
              onClick={() => {
                setShowDeleteChatsConfirm(true)
                setShowMenu(false)
              }}
              className="w-full text-right px-4 py-3 text-red-600 hover:bg-red-50 rounded-lg flex items-center gap-2 justify-end text-sm font-medium border-b border-gray-200"
            >
              <Trash2 size={16} />
              حذف المحادثات
            </button>
            <button
              onClick={handleLogout}
              className="w-full text-right px-4 py-3 text-red-600 hover:bg-red-50 rounded-lg flex items-center gap-2 justify-end text-sm font-medium"
            >
              <LogOut size={16} />
              تسجيل الخروج
            </button>
          </div>
        )}
      </div>

      {/* Users List */}
      <div className="flex-1 overflow-y-auto">
        {displayUsers.length === 0 ? (
          <div className="p-4 text-center text-gray-500 text-sm">
            {searchTerm ? "لا توجد نتائج" : "لا توجد محادثات"}
          </div>
        ) : (
          displayUsers.map((user) => (
            <button
              key={user.uid}
              onClick={() => {
                onSelectUser(user)
                onSearch("")
              }}
              className={`w-full text-right p-4 border-b border-gray-200 hover:bg-gray-50 transition flex items-center gap-3 ${
                selectedUser?.uid === user.uid ? "bg-indigo-50 border-r-4 border-r-indigo-600" : ""
              }`}
            >
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-indigo-600 to-purple-600 text-white flex items-center justify-center font-bold flex-shrink-0 text-lg">
                {user.avatar}
              </div>
              <div className="min-w-0 flex-1">
                <h3 className="font-semibold text-gray-900 text-sm">{user.name}</h3>
                {blockedUsers[user.uid] && <p className="text-xs text-red-600 font-medium">محظور</p>}
              </div>
            </button>
          ))
        )}
      </div>

      {/* Delete All Chats Confirmation Modal */}
      {showDeleteChatsConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-6 max-w-sm w-full">
            <h3 className="text-lg font-bold text-red-600 mb-2">حذف جميع المحادثات</h3>
            <p className="text-gray-600 mb-4 text-sm">
              هل أنت متأكد من حذف جميع محادثاتك؟ لا يمكن التراجع عن هذا الإجراء.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowDeleteChatsConfirm(false)}
                className="flex-1 bg-gray-200 text-gray-900 py-2 rounded-lg font-medium hover:bg-gray-300 transition"
              >
                إلغاء
              </button>
              <button
                onClick={handleDeleteAllChats}
                disabled={isDeleting}
                className="flex-1 bg-red-600 text-white py-2 rounded-lg font-medium hover:bg-red-700 transition disabled:opacity-50"
              >
                {isDeleting ? "جاري الحذف..." : "حذف"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
