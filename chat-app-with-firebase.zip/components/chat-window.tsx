"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import type { User } from "firebase/auth"
import type { UserProfile } from "@/lib/auth-service"
import { chatService, type Message } from "@/lib/chat-service"
import { blockService } from "@/lib/block-service"
import { storageService } from "@/lib/storage-service"
import { MoreVertical, ArrowRight, ImageIcon, Trash2 } from "lucide-react"

interface Props {
  currentUser: User
  currentUserProfile: UserProfile
  selectedUser: UserProfile
  onBack: () => void
  blockedUsers: Record<string, boolean>
}

export function ChatWindow({ currentUser, currentUserProfile, selectedUser, onBack, blockedUsers }: Props) {
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [showMenu, setShowMenu] = useState<string | null>(null)
  const [showUserMenu, setShowUserMenu] = useState(false)
  const [isUserBlocked, setIsUserBlocked] = useState(false)
  const [showDeleteChatConfirm, setShowDeleteChatConfirm] = useState(false)
  const [isUploadingImage, setIsUploadingImage] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    setIsUserBlocked(blockedUsers[selectedUser.uid] === true)
  }, [selectedUser.uid, blockedUsers])

  useEffect(() => {
    // Load initial messages
    const loadMessages = async () => {
      const initialMessages = await chatService.getMessages(currentUser.uid, selectedUser.uid)
      setMessages(initialMessages)
      scrollToBottom()
    }

    loadMessages()

    // Listen for new messages
    const unsubscribe = chatService.onMessagesChanged(currentUser.uid, selectedUser.uid, (newMessages) => {
      setMessages(newMessages)
      scrollToBottom()
    })

    return () => unsubscribe()
  }, [currentUser.uid, selectedUser.uid])

  const scrollToBottom = () => {
    setTimeout(() => {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
    }, 0)
  }

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newMessage.trim() || isLoading || isUserBlocked) return

    setIsLoading(true)
    try {
      await chatService.sendMessage(currentUser.uid, currentUserProfile.name, selectedUser.uid, newMessage)
      setNewMessage("")
    } catch (error) {
      console.error("خطأ في إرسال الرسالة:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleDeleteMessage = async (messageId: string) => {
    try {
      await chatService.deleteMessage(currentUser.uid, selectedUser.uid, messageId)
      setShowMenu(null)
    } catch (error) {
      console.error("خطأ في حذف الرسالة:", error)
    }
  }

  const handleBlockUser = async () => {
    try {
      await blockService.blockUser(currentUser.uid, selectedUser.uid)
      setIsUserBlocked(true)
      setShowUserMenu(false)
    } catch (error) {
      console.error("خطأ في حظر المستخدم:", error)
    }
  }

  const handleUnblockUser = async () => {
    try {
      await blockService.unblockUser(currentUser.uid, selectedUser.uid)
      setIsUserBlocked(false)
      setShowUserMenu(false)
    } catch (error) {
      console.error("خطأ في فك الحظر:", error)
    }
  }

  const handleDeleteChat = async () => {
    try {
      await chatService.deleteSpecificChat(currentUser.uid, selectedUser.uid)
      setShowDeleteChatConfirm(false)
      onBack()
    } catch (error) {
      console.error("خطأ في حذف المحادثة:", error)
    }
  }

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setIsUploadingImage(true)
    try {
      const imageUrl = await storageService.uploadChatImage(currentUser.uid, selectedUser.uid, file)
      await chatService.sendMessage(currentUser.uid, currentUserProfile.name, selectedUser.uid, "", imageUrl)
      setNewMessage("")
    } catch (error) {
      console.error("خطأ في رفع الصورة:", error)
    } finally {
      setIsUploadingImage(false)
      if (fileInputRef.current) fileInputRef.current.value = ""
    }
  }

  return (
    <div className="flex flex-col h-screen bg-white dark:bg-gray-900">
      {/* Chat Header */}
      <div className="p-4 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-3 flex-1">
          <button
            onClick={onBack}
            className="text-indigo-600 dark:text-indigo-400 hover:bg-gray-100 dark:hover:bg-gray-700 p-2 rounded-lg"
          >
            <ArrowRight size={20} />
          </button>
          <button
            onClick={() => {
              window.location.href = `/user/${selectedUser.uid}`
            }}
            className="hover:opacity-80 transition rounded-full"
          >
            {selectedUser.profileImage ? (
              <img
                src={selectedUser.profileImage || "/placeholder.svg"}
                alt={selectedUser.name}
                className="w-10 h-10 rounded-full object-cover flex-shrink-0"
              />
            ) : (
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-600 to-purple-600 text-white flex items-center justify-center font-bold flex-shrink-0">
                {selectedUser.avatar}
              </div>
            )}
          </button>
          <div>
            <h2 className="font-semibold text-gray-900 dark:text-white">{selectedUser.name}</h2>
            <p className="text-xs text-indigo-600 dark:text-indigo-400 font-semibold">
              @{selectedUser.username || "username"}
            </p>
          </div>
        </div>

        <div className="relative">
          <button
            onClick={() => setShowUserMenu(!showUserMenu)}
            className="text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 p-2 rounded-lg"
          >
            <MoreVertical size={20} />
          </button>

          {showUserMenu && (
            <div className="absolute left-0 mt-2 w-48 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg z-50">
              <button
                onClick={() => {
                  setShowDeleteChatConfirm(true)
                  setShowUserMenu(false)
                }}
                className="w-full text-right px-4 py-3 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 border-b border-gray-200 dark:border-gray-700 text-sm flex items-center gap-2 justify-end"
              >
                <Trash2 size={16} />
                حذف المحادثة
              </button>
              {isUserBlocked ? (
                <button
                  onClick={handleUnblockUser}
                  className="w-full text-right px-4 py-3 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 text-sm"
                >
                  فك الحظر
                </button>
              ) : (
                <button
                  onClick={handleBlockUser}
                  className="w-full text-right px-4 py-3 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 text-sm"
                >
                  حظر المستخدم
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50 dark:bg-gray-950">
        {messages.length === 0 ? (
          <div className="flex items-center justify-center h-full text-gray-500 dark:text-gray-400">
            ابدأ محادثة جديدة
          </div>
        ) : (
          messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.senderId === currentUser.uid ? "justify-end" : "justify-start"} group`}
              onMouseEnter={() => setShowMenu(message.id || null)}
              onMouseLeave={() => setShowMenu(null)}
            >
              <div className="flex items-end gap-2">
                {message.senderId === currentUser.uid && showMenu === message.id && (
                  <button
                    onClick={() => handleDeleteMessage(message.id!)}
                    className="text-red-600 dark:text-red-400 hover:text-red-700 dark:hover:text-red-300 text-xs p-1 opacity-0 group-hover:opacity-100 transition"
                  >
                    حذف
                  </button>
                )}

                <div
                  className={`max-w-xs px-4 py-2 rounded-lg ${
                    message.senderId === currentUser.uid
                      ? "bg-indigo-600 text-white"
                      : "bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white"
                  }`}
                >
                  {message.imageUrl && (
                    <img
                      src={message.imageUrl || "/placeholder.svg"}
                      alt="رسالة صورة"
                      className="max-w-xs rounded-lg mb-2"
                    />
                  )}
                  {message.text && <p className="break-words text-sm">{message.text}</p>}
                  <p
                    className={`text-xs mt-1 ${
                      message.senderId === currentUser.uid ? "text-indigo-100" : "text-gray-500 dark:text-gray-400"
                    }`}
                  >
                    {new Date(message.timestamp).toLocaleTimeString("ar-SA", {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </p>
                </div>
              </div>
            </div>
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-4 border-t border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 sticky bottom-0">
        {isUserBlocked && (
          <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-400 text-xs p-2 rounded mb-2 text-center">
            لا يمكن الرسائل - هذا المستخدم محظور
          </div>
        )}
        <form
          onSubmit={(e) => {
            e.preventDefault()
            if (!newMessage.trim() || isLoading || isUserBlocked) return
            setIsLoading(true)
            chatService
              .sendMessage(currentUser.uid, currentUserProfile.name, selectedUser.uid, newMessage)
              .then(() => {
                setNewMessage("")
              })
              .finally(() => setIsLoading(false))
          }}
          className="flex gap-2"
        >
          <input type="file" ref={fileInputRef} onChange={handleImageUpload} accept="image/*" className="hidden" />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={isUploadingImage || isUserBlocked}
            className="px-3 py-2 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-lg hover:bg-indigo-200 dark:hover:bg-indigo-900/50 transition disabled:opacity-50 flex-shrink-0"
          >
            <ImageIcon size={18} />
          </button>
          <input
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder={isUserBlocked ? "محظور" : "اكتب رسالتك..."}
            disabled={isLoading || isUserBlocked}
            className="flex-1 px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:border-indigo-600 dark:focus:border-indigo-400 text-sm disabled:bg-gray-100 dark:disabled:bg-gray-800 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
          />
          <button
            type="submit"
            disabled={isLoading || !newMessage.trim() || isUserBlocked}
            className="px-4 py-2 bg-indigo-600 dark:bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 dark:hover:bg-indigo-700 transition disabled:opacity-50 text-sm font-medium"
          >
            إرسال
          </button>
        </form>
      </div>

      {/* Delete Chat Confirmation Modal */}
      {showDeleteChatConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 max-w-sm w-full">
            <h3 className="text-lg font-bold text-red-600 dark:text-red-400 mb-2">حذف المحادثة</h3>
            <p className="text-gray-600 dark:text-gray-400 mb-4 text-sm">
              هل أنت متأكد من حذف هذه المحادثة؟ لا يمكن التراجع عن هذا الإجراء.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowDeleteChatConfirm(false)}
                className="flex-1 bg-gray-200 dark:bg-gray-700 text-gray-900 dark:text-white py-2 rounded-lg font-medium hover:bg-gray-300 dark:hover:bg-gray-600 transition"
              >
                إلغاء
              </button>
              <button
                onClick={handleDeleteChat}
                className="flex-1 bg-red-600 dark:bg-red-600 text-white py-2 rounded-lg font-medium hover:bg-red-700 dark:hover:bg-red-700 transition"
              >
                حذف
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
