// UI Helper Functions - DOM manipulation utilities

/**
 * Show element
 * @param {HTMLElement} element - Element to show
 */
export function show(element) {
  element?.classList.remove("hidden")
}

/**
 * Hide element
 * @param {HTMLElement} element - Element to hide
 */
export function hide(element) {
  element?.classList.add("hidden")
}

/**
 * Toggle element visibility
 * @param {HTMLElement} element - Element to toggle
 */
export function toggle(element) {
  element?.classList.toggle("hidden")
}

/**
 * Get element by ID
 * @param {string} id - Element ID
 * @returns {HTMLElement|null} - Element or null
 */
export function getEl(id) {
  return document.getElementById(id)
}

/**
 * Query selector
 * @param {string} selector - CSS selector
 * @returns {HTMLElement|null} - Element or null
 */
export function query(selector) {
  return document.querySelector(selector)
}

/**
 * Query selector all
 * @param {string} selector - CSS selector
 * @returns {NodeList} - Elements
 */
export function queryAll(selector) {
  return document.querySelectorAll(selector)
}

/**
 * Create element with attributes
 * @param {string} tag - Tag name
 * @param {Object} attributes - Element attributes
 * @param {string} content - Inner HTML
 * @returns {HTMLElement} - Created element
 */
export function createElement(tag, attributes = {}, content = "") {
  const el = document.createElement(tag)

  Object.entries(attributes).forEach(([key, value]) => {
    if (key === "class") {
      el.className = value
    } else if (key === "style") {
      Object.assign(el.style, value)
    } else {
      el.setAttribute(key, value)
    }
  })

  if (content) el.innerHTML = content

  return el
}

/**
 * Add event listener
 * @param {HTMLElement} element - Element
 * @param {string} event - Event name
 * @param {Function} callback - Callback function
 */
export function on(element, event, callback) {
  element?.addEventListener(event, callback)
}

/**
 * Remove event listener
 * @param {HTMLElement} element - Element
 * @param {string} event - Event name
 * @param {Function} callback - Callback function
 */
export function off(element, event, callback) {
  element?.removeEventListener(event, callback)
}

/**
 * Add class
 * @param {HTMLElement} element - Element
 * @param {string} className - Class name
 */
export function addClass(element, className) {
  element?.classList.add(className)
}

/**
 * Remove class
 * @param {HTMLElement} element - Element
 * @param {string} className - Class name
 */
export function removeClass(element, className) {
  element?.classList.remove(className)
}

/**
 * Check if element has class
 * @param {HTMLElement} element - Element
 * @param {string} className - Class name
 * @returns {boolean} - Has class
 */
export function hasClass(element, className) {
  return element?.classList.contains(className)
}

/**
 * Set text content
 * @param {HTMLElement} element - Element
 * @param {string} text - Text content
 */
export function setText(element, text) {
  if (element) element.textContent = text
}

/**
 * Get text content
 * @param {HTMLElement} element - Element
 * @returns {string} - Text content
 */
export function getText(element) {
  return element?.textContent || ""
}

/**
 * Set HTML content
 * @param {HTMLElement} element - Element
 * @param {string} html - HTML content
 */
export function setHTML(element, html) {
  if (element) element.innerHTML = html
}

/**
 * Get HTML content
 * @param {HTMLElement} element - Element
 * @returns {string} - HTML content
 */
export function getHTML(element) {
  return element?.innerHTML || ""
}

/**
 * Set attribute
 * @param {HTMLElement} element - Element
 * @param {string} name - Attribute name
 * @param {string} value - Attribute value
 */
export function setAttribute(element, name, value) {
  element?.setAttribute(name, value)
}

/**
 * Get attribute
 * @param {HTMLElement} element - Element
 * @param {string} name - Attribute name
 * @returns {string|null} - Attribute value
 */
export function getAttribute(element, name) {
  return element?.getAttribute(name)
}

/**
 * Show error message
 * @param {string} elementId - Error element ID
 * @param {string} message - Error message
 */
export function showError(elementId, message) {
  const errorEl = getEl(elementId)
  if (errorEl) {
    setText(errorEl, message)
    show(errorEl)
  }
}

/**
 * Clear error message
 * @param {string} elementId - Error element ID
 */
export function clearError(elementId) {
  const errorEl = getEl(elementId)
  if (errorEl) {
    setText(errorEl, "")
    hide(errorEl)
  }
}

/**
 * Escape HTML to prevent XSS
 * @param {string} text - Text to escape
 * @returns {string} - Escaped HTML
 */
export function escapeHtml(text) {
  const div = document.createElement("div")
  div.textContent = text
  return div.innerHTML
}
