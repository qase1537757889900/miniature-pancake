// Message Service - Handles all message operations

import { database } from "../config/firebase-config.js"

/**
 * Generate unique chat ID from two user IDs
 * @param {string} user1Id - First user ID
 * @param {string} user2Id - Second user ID
 * @returns {string} - Unique chat ID
 */
export function getChatId(user1Id, user2Id) {
  return [user1Id, user2Id].sort().join("_")
}

/**
 * Send message to database
 * @param {string} senderId - Sender user ID
 * @param {string} recipientId - Recipient user ID
 * @param {string} text - Message text
 * @returns {Promise} - Send result
 */
export async function sendMessage(senderId, recipientId, text) {
  if (!text.trim()) {
    return { success: false, error: "الرسالة فارغة" }
  }

  const chatId = getChatId(senderId, recipientId)
  const messageId = database.ref(`messages/${chatId}`).push().key

  try {
    await database.ref(`messages/${chatId}/${messageId}`).set({
      text: text.trim(),
      senderId: senderId,
      timestamp: new Date().toISOString(),
    })
    return { success: true, messageId }
  } catch (error) {
    console.error("Error sending message:", error)
    return { success: false, error: error.message }
  }
}

/**
 * Load all messages for a chat
 * @param {string} user1Id - First user ID
 * @param {string} user2Id - Second user ID
 * @returns {Promise<Array>} - Messages array
 */
export async function loadMessages(user1Id, user2Id) {
  const chatId = getChatId(user1Id, user2Id)

  try {
    const snapshot = await database.ref(`messages/${chatId}`).once("value")
    const messages = snapshot.val() || {}
    return Object.entries(messages).map(([id, data]) => ({ id, ...data }))
  } catch (error) {
    console.error("Error loading messages:", error)
    return []
  }
}

/**
 * Delete a message
 * @param {string} user1Id - First user ID
 * @param {string} user2Id - Second user ID
 * @param {string} messageId - Message ID to delete
 * @returns {Promise} - Delete result
 */
export async function deleteMessage(user1Id, user2Id, messageId) {
  const chatId = getChatId(user1Id, user2Id)

  try {
    await database.ref(`messages/${chatId}/${messageId}`).remove()
    return { success: true }
  } catch (error) {
    console.error("Error deleting message:", error)
    return { success: false, error: error.message }
  }
}

/**
 * Setup realtime listener for messages
 * @param {string} user1Id - First user ID
 * @param {string} user2Id - Second user ID
 * @param {Function} callback - Callback function
 * @returns {Function} - Unsubscribe function
 */
export function listenToMessages(user1Id, user2Id, callback) {
  const chatId = getChatId(user1Id, user2Id)

  const ref = database.ref(`messages/${chatId}`)
  ref.on("value", (snapshot) => {
    const messages = snapshot.val() || {}
    const messageArray = Object.entries(messages).map(([id, data]) => ({ id, ...data }))
    callback(messageArray)
  })

  return () => ref.off()
}
