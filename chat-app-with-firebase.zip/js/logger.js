// Logger Service - Logging utility for debugging

export const LOG_LEVELS = {
  DEBUG: "DEBUG",
  INFO: "INFO",
  WARN: "WARN",
  ERROR: "ERROR",
}

class Logger {
  constructor(enableDebug = false) {
    this.enableDebug = enableDebug
  }

  /**
   * Log debug message
   * @param {string} message - Log message
   * @param {*} data - Additional data
   */
  debug(message, data = null) {
    if (this.enableDebug) {
      console.log(`[${LOG_LEVELS.DEBUG}] ${message}`, data)
    }
  }

  /**
   * Log info message
   * @param {string} message - Log message
   * @param {*} data - Additional data
   */
  info(message, data = null) {
    console.log(`[${LOG_LEVELS.INFO}] ${message}`, data)
  }

  /**
   * Log warning message
   * @param {string} message - Log message
   * @param {*} data - Additional data
   */
  warn(message, data = null) {
    console.warn(`[${LOG_LEVELS.WARN}] ${message}`, data)
  }

  /**
   * Log error message
   * @param {string} message - Log message
   * @param {*} error - Error object or data
   */
  error(message, error = null) {
    console.error(`[${LOG_LEVELS.ERROR}] ${message}`, error)
  }
}

export const logger = new Logger(false)
