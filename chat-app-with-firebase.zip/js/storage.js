// Local Storage Service - Handle local storage operations

/**
 * Set item in localStorage
 * @param {string} key - Storage key
 * @param {*} value - Value to store
 */
export function setStorageItem(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value))
  } catch (error) {
    console.error("Error setting storage item:", error)
  }
}

/**
 * Get item from localStorage
 * @param {string} key - Storage key
 * @returns {*} - Stored value or null
 */
export function getStorageItem(key) {
  try {
    const item = localStorage.getItem(key)
    return item ? JSON.parse(item) : null
  } catch (error) {
    console.error("Error getting storage item:", error)
    return null
  }
}

/**
 * Remove item from localStorage
 * @param {string} key - Storage key
 */
export function removeStorageItem(key) {
  try {
    localStorage.removeItem(key)
  } catch (error) {
    console.error("Error removing storage item:", error)
  }
}

/**
 * Clear all localStorage
 */
export function clearStorage() {
  try {
    localStorage.clear()
  } catch (error) {
    console.error("Error clearing storage:", error)
  }
}

// Storage Keys
export const STORAGE_KEYS = {
  userPreferences: "userPreferences",
  chatHistory: "chatHistory",
  theme: "theme",
  language: "language",
}
