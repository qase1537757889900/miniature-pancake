// Authentication Page Logic

// Declare loginUser, registerUser, showError, getEl, and toggle functions
async function loginUser(email, password) {
  // Placeholder for login logic
  return { success: true } // or { success: false, error: 'Error message' }
}

async function registerUser(name, email, password) {
  // Placeholder for register logic
  return { success: true } // or { success: false, error: 'Error message' }
}

function showError(elementId, errorMessage) {
  const errorEl = document.getElementById(elementId)
  if (errorEl) {
    errorEl.textContent = errorMessage
  }
}

function getEl(id) {
  return document.getElementById(id)
}

function toggle(element) {
  if (element) {
    element.style.display = element.style.display === "none" ? "block" : "none"
  }
}

function clearError(elementId) {
  const errorEl = document.getElementById(elementId)
  if (errorEl) {
    errorEl.textContent = ""
  }
}

document.getElementById("loginFormElement")?.addEventListener("submit", async (e) => {
  e.preventDefault()

  const email = document.getElementById("loginEmail").value
  const password = document.getElementById("loginPassword").value
  const errorEl = document.getElementById("loginError")

  try {
    const result = await loginUser(email, password)

    if (result.success) {
      window.location.href = "pages/chat.html"
    } else {
      showError("loginError", result.error)
    }
  } catch (error) {
    showError("loginError", "حدث خطأ غير متوقع")
  }
})

document.getElementById("registerFormElement")?.addEventListener("submit", async (e) => {
  e.preventDefault()

  const name = document.getElementById("registerName").value
  const email = document.getElementById("registerEmail").value
  const password = document.getElementById("registerPassword").value

  try {
    const result = await registerUser(name, email, password)

    if (result.success) {
      window.location.href = "pages/chat.html"
    } else {
      showError("registerError", result.error)
    }
  } catch (error) {
    showError("registerError", "حدث خطأ غير متوقع")
  }
})

/**
 * Toggle between login and register forms
 */
function toggleAuthForm() {
  const loginForm = getEl("loginForm")
  const registerForm = getEl("registerForm")

  toggle(loginForm)
  toggle(registerForm)

  // Clear errors when switching forms
  clearError("loginError")
  clearError("registerError")
}
