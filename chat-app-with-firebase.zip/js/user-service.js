// User Service - Handles all user operations

import { auth, database } from "../config/firebase-config.js"

/**
 * Load all users
 * @returns {Promise<Object>} - Users object
 */
export async function loadAllUsers() {
  try {
    const snapshot = await database.ref("users").once("value")
    return snapshot.val() || {}
  } catch (error) {
    console.error("Error loading users:", error)
    return {}
  }
}

/**
 * Get current user info
 * @returns {Promise<Object|null>} - User data or null
 */
export async function getCurrentUserInfo() {
  try {
    const userId = auth.currentUser?.uid
    if (!userId) return null

    const snapshot = await database.ref(`users/${userId}`).once("value")
    return snapshot.val()
  } catch (error) {
    console.error("Error loading user info:", error)
    return null
  }
}

/**
 * Get specific user info
 * @param {string} userId - User ID
 * @returns {Promise<Object|null>} - User data or null
 */
export async function getUserInfo(userId) {
  try {
    const snapshot = await database.ref(`users/${userId}`).once("value")
    return snapshot.val()
  } catch (error) {
    console.error("Error loading user info:", error)
    return null
  }
}

/**
 * Search users by name or email
 * @param {Object} users - Users object
 * @param {string} query - Search query
 * @param {string} excludeUserId - User ID to exclude
 * @returns {Array} - Search results
 */
export function searchUsers(users, query, excludeUserId) {
  const lowerQuery = query.toLowerCase()
  return Object.entries(users).filter(([userId, userData]) => {
    return (
      userId !== excludeUserId &&
      (userData.name.toLowerCase().includes(lowerQuery) || userData.email.toLowerCase().includes(lowerQuery))
    )
  })
}

/**
 * Update user profile
 * @param {string} userId - User ID
 * @param {Object} data - Data to update
 * @returns {Promise} - Update result
 */
export async function updateUserProfile(userId, data) {
  try {
    await database.ref(`users/${userId}`).update(data)
    return { success: true }
  } catch (error) {
    console.error("Error updating user profile:", error)
    return { success: false, error: error.message }
  }
}

/**
 * Get user status (online/offline)
 * @param {string} userId - User ID
 * @returns {Promise<string>} - User status
 */
export async function getUserStatus(userId) {
  try {
    const snapshot = await database.ref(`users/${userId}/status`).once("value")
    return snapshot.val() || "offline"
  } catch (error) {
    return "offline"
  }
}
