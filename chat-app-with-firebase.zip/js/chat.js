// Chat Page Logic

import { auth } from "./firebaseConfig" // Import auth from firebaseConfig
import { getCurrentUserInfo } from "./userUtils" // Import getCurrentUserInfo from userUtils
import { getEl } from "./domUtils" // Import getEl from domUtils
import { loadAllUsers } from "./userUtils" // Import loadAllUsers from userUtils
import { createElement } from "./domUtils" // Import createElement from domUtils
import { hide } from "./domUtils" // Import hide from domUtils
import { searchUsers } from "./searchUtils" // Import searchUsers from searchUtils
import { show } from "./domUtils" // Import show from domUtils
import { escapeHtml } from "./utils" // Import escapeHtml from utils
import { sendMessage } from "./messageUtils" // Import sendMessage from messageUtils
import { toggle } from "./domUtils" // Import toggle from domUtils
import { logoutUser } from "./authUtils" // Import logoutUser from authUtils

let currentUserId = null
let currentChatUser = null
let usersCache = {}
let messagesRefreshInterval = null

// Initialize on auth state change
auth.onAuthStateChanged(async (user) => {
  if (user) {
    currentUserId = user.uid
    await initializeChat()
  } else {
    window.location.href = "../index.html"
  }
})

/**
 * Initialize chat application
 */
async function initializeChat() {
  try {
    await loadCurrentUserInfo()
    await loadUsersList()
    setupAutoRefresh()
  } catch (error) {
    console.error("Error initializing chat:", error)
  }
}

/**
 * Load current user info and update avatar
 */
async function loadCurrentUserInfo() {
  try {
    const userData = await getCurrentUserInfo()
    if (userData) {
      getEl("userAvatar").textContent = userData.avatar || "U"
    }
  } catch (error) {
    console.error("Error loading user info:", error)
  }
}

/**
 * Load all users list
 */
async function loadUsersList() {
  try {
    usersCache = await loadAllUsers()
    displayChatsList(usersCache)
  } catch (error) {
    console.error("Error loading users:", error)
  }
}

/**
 * Display users in chats list
 * @param {object} users - Users data
 */
function displayChatsList(users) {
  const chatsList = getEl("chatsList")
  chatsList.innerHTML = ""

  Object.entries(users).forEach(([userId, userData]) => {
    if (userId !== currentUserId) {
      const chatItem = createElement(
        "div",
        "chat-item",
        `
                    <span class="avatar">${userData.avatar || "U"}</span>
                    <div class="chat-item-content">
                        <div class="chat-item-name">${userData.name}</div>
                        <div class="chat-item-preview">اضغط لبدء محادثة</div>
                    </div>
                `,
      )

      chatItem.onclick = () => selectChat(userId, userData)
      chatsList.appendChild(chatItem)
    }
  })
}

/**
 * Handle user search
 */
async function handleSearch() {
  const searchInput = getEl("searchInput")
  const searchResults = getEl("searchResults")
  const query = searchInput.value

  if (!query.trim()) {
    hide(searchResults)
    return
  }

  const results = searchUsers(usersCache, query, currentUserId)

  if (results.length === 0) {
    searchResults.innerHTML =
      '<div style="padding: 12px; text-align: center; color: var(--text-secondary);">لم يتم العثور على نتائج</div>'
  } else {
    searchResults.innerHTML = results
      .map(
        ([userId, userData]) => `
            <div class="search-result-item" onclick="selectChat('${userId}', ${JSON.stringify(userData).replace(/"/g, "&quot;")})">
                <span class="avatar">${userData.avatar || "U"}</span>
                <div>
                    <div style="font-weight: 600; font-size: 14px;">${userData.name}</div>
                    <div style="font-size: 12px; color: var(--text-secondary);">${userData.email}</div>
                </div>
            </div>
        `,
      )
      .join("")
  }

  show(searchResults)
}

/**
 * Select chat with a user
 * @param {string} userId - User ID
 * @param {object} userData - User data
 */
function selectChat(userId, userData) {
  currentChatUser = { id: userId, ...userData }

  hide(getEl("noChatSelected"))
  show(getEl("chatWindow"))
  getEl("chatUserName").textContent = userData.name
  getEl("chatUserAvatar").textContent = userData.avatar || "U"
  hide(getEl("searchResults"))
  getEl("searchInput").value = ""
  getEl("messageInput").value = ""

  loadMessages()
}

/**
 * Load and display messages
 */
async function loadMessages() {
  if (!currentChatUser) return

  try {
    const messages = await loadMessages(currentUserId, currentChatUser.id)
    const container = getEl("messagesContainer")
    container.innerHTML = ""

    messages.forEach((msg) => {
      const messageEl = createElement("div", `message ${msg.senderId === currentUserId ? "sent" : "received"}`)
      messageEl.innerHTML = `<div class="message-content">${escapeHtml(msg.text)}</div>`
      container.appendChild(messageEl)
    })

    // Scroll to bottom
    container.scrollTop = container.scrollHeight
  } catch (error) {
    console.error("Error loading messages:", error)
  }
}

/**
 * Handle send message
 */
async function handleSendMessage() {
  if (!currentChatUser) return

  const messageInput = getEl("messageInput")
  const text = messageInput.value

  const result = await sendMessage(currentUserId, currentChatUser.id, text)

  if (result.success) {
    messageInput.value = ""
    await loadMessages()
  }
}

/**
 * Handle key press in message input
 * @param {KeyboardEvent} event
 */
function handleKeyPress(event) {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault()
    handleSendMessage()
  }
}

/**
 * Setup auto-refresh for messages
 */
function setupAutoRefresh() {
  messagesRefreshInterval = setInterval(() => {
    if (currentChatUser) {
      loadMessages()
    }
  }, 1000)
}

/**
 * Toggle user menu
 */
function toggleUserMenu() {
  toggle(getEl("userMenu"))
}

/**
 * Navigate to profile page
 */
function goToProfile() {
  window.location.href = "profile.html"
}

/**
 * Handle logout
 */
async function handleLogout() {
  if (messagesRefreshInterval) clearInterval(messagesRefreshInterval)
  await logoutUser()
}

// Close menu when clicking outside
document.addEventListener("click", (e) => {
  const userMenu = getEl("userMenu")
  const userMenuBtn = document.querySelector(".user-menu-btn")

  if (userMenu && !userMenu.contains(e.target) && !userMenuBtn?.contains(e.target)) {
    hide(userMenu)
  }
})
