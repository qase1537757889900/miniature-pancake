// Authentication Service - Handles all auth operations

import { auth, database } from "../config/firebase-config.js"

/**
 * Get error message based on Firebase error code
 * @param {string} code - Firebase error code
 * @returns {string} - User-friendly error message
 */
export function getErrorMessage(code) {
  const messages = {
    "auth/email-already-in-use": "البريد الإلكتروني مستخدم بالفعل",
    "auth/weak-password": "كلمة المرور ضعيفة جداً (يجب أن تكون 6 أحرف على الأقل)",
    "auth/user-not-found": "المستخدم غير موجود",
    "auth/wrong-password": "كلمة المرور خاطئة",
    "auth/invalid-email": "البريد الإلكتروني غير صحيح",
    "auth/operation-not-allowed": "هذه العملية غير متاحة حالياً",
    "auth/too-many-requests": "عدد محاولات كثير جداً. حاول لاحقاً",
    "auth/network-request-failed": "خطأ في الاتصال بالإنترنت",
  }
  return messages[code] || "حدث خطأ ما. حاول مرة أخرى"
}

/**
 * Register new user
 * @param {string} name - User name
 * @param {string} email - User email
 * @param {string} password - User password
 * @returns {Promise<Object>} - Registration result
 */
export async function registerUser(name, email, password) {
  try {
    const userCredential = await auth.createUserWithEmailAndPassword(email, password)
    const userId = userCredential.user.uid

    // Save user data to database
    await database.ref("users/" + userId).set({
      name: name,
      email: email,
      createdAt: new Date().toISOString(),
      avatar: name.charAt(0).toUpperCase(),
      uid: userId,
      status: "online",
    })

    return { success: true, userId }
  } catch (error) {
    return { success: false, error: getErrorMessage(error.code) }
  }
}

/**
 * Login user
 * @param {string} email - User email
 * @param {string} password - User password
 * @returns {Promise<Object>} - Login result
 */
export async function loginUser(email, password) {
  try {
    await auth.signInWithEmailAndPassword(email, password)
    return { success: true }
  } catch (error) {
    return { success: false, error: getErrorMessage(error.code) }
  }
}

/**
 * Logout user
 * @returns {Promise<Object>} - Logout result
 */
export async function logoutUser() {
  try {
    await auth.signOut()
    return { success: true }
  } catch (error) {
    return { success: false, error: error.message }
  }
}

/**
 * Get current user
 * @returns {Object|null} - Current user or null
 */
export function getCurrentUser() {
  return auth.currentUser
}

/**
 * Subscribe to auth state changes
 * @param {Function} callback - Callback function
 * @returns {Function} - Unsubscribe function
 */
export function onAuthStateChanged(callback) {
  return auth.onAuthStateChanged(callback)
}

/**
 * Reset password
 * @param {string} email - User email
 * @returns {Promise<Object>} - Reset result
 */
export async function resetPassword(email) {
  try {
    await auth.sendPasswordResetEmail(email)
    return { success: true }
  } catch (error) {
    return { success: false, error: getErrorMessage(error.code) }
  }
}
