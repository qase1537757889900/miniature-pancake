// Validation Service - Handles all form validations

/**
 * Validate email format
 * @param {string} email - Email to validate
 * @returns {boolean} - Is valid
 */
export function validateEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

/**
 * Validate password strength
 * @param {string} password - Password to validate
 * @returns {Object} - Validation result
 */
export function validatePassword(password) {
  const result = {
    isValid: password.length >= 6,
    strength: "weak",
    requirements: {
      minLength: password.length >= 6,
      hasUpperCase: /[A-Z]/.test(password),
      hasLowerCase: /[a-z]/.test(password),
      hasNumbers: /\d/.test(password),
      hasSpecial: /[!@#$%^&*]/.test(password),
    },
  }

  // Calculate strength
  const requirementsMet = Object.values(result.requirements).filter(Boolean).length
  if (requirementsMet >= 4) result.strength = "strong"
  else if (requirementsMet >= 2) result.strength = "medium"

  return result
}

/**
 * Validate username
 * @param {string} name - Username to validate
 * @returns {boolean} - Is valid
 */
export function validateUsername(name) {
  return name.trim().length >= 2 && name.trim().length <= 50
}

/**
 * Validate required field
 * @param {string} value - Value to validate
 * @returns {boolean} - Is valid
 */
export function validateRequired(value) {
  return value.trim().length > 0
}

/**
 * Validate message
 * @param {string} message - Message to validate
 * @returns {boolean} - Is valid
 */
export function validateMessage(message) {
  return message.trim().length > 0 && message.trim().length <= 5000
}

/**
 * Validate login form
 * @param {string} email - Email
 * @param {string} password - Password
 * @returns {Object} - Validation result
 */
export function validateLoginForm(email, password) {
  const errors = {}

  if (!validateEmail(email)) {
    errors.email = "البريد الإلكتروني غير صحيح"
  }

  if (!validateRequired(password)) {
    errors.password = "كلمة المرور مطلوبة"
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  }
}

/**
 * Validate register form
 * @param {string} name - Username
 * @param {string} email - Email
 * @param {string} password - Password
 * @returns {Object} - Validation result
 */
export function validateRegisterForm(name, email, password) {
  const errors = {}

  if (!validateUsername(name)) {
    errors.name = "اسم المستخدم يجب أن يكون بين 2 و 50 حرف"
  }

  if (!validateEmail(email)) {
    errors.email = "البريد الإلكتروني غير صحيح"
  }

  if (!validatePassword(password).isValid) {
    errors.password = "كلمة المرور ضعيفة جداً (يجب أن تكون 6 أحرف على الأقل)"
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  }
}
