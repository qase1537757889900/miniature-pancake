// Profile Page Logic

// Declare variables
const firebase = window.firebase // Assuming firebase is available globally
const auth = firebase.auth() // Assuming firebase is imported and available
const db = firebase.firestore() // Assuming firebase is imported and available

// Initialize on page load
auth.onAuthStateChanged(async (user) => {
  if (user) {
    await loadUserProfile(user.uid)
  } else {
    window.location.href = "../index.html"
  }
})

/**
 * Load and display user profile
 * @param {string} userId - User ID
 */
async function loadUserProfile(userId) {
  try {
    const userData = await getCurrentUserInfo(userId)

    if (userData) {
      document.getElementById("profileAvatarLarge").textContent = userData.avatar || "U"
      document.getElementById("profileName").textContent = userData.name
      document.getElementById("profileEmail").textContent = userData.email
      document.getElementById("displayName").textContent = userData.name
      document.getElementById("displayEmail").textContent = userData.email

      const joinDate = formatDate(userData.createdAt)
      document.getElementById("joinDate").textContent = joinDate
    }
  } catch (error) {
    console.error("Error loading profile:", error)
  }
}

/**
 * Get current user info from Firestore
 * @param {string} userId - User ID
 * @returns {Promise<Object|null>} User data or null if not found
 */
async function getCurrentUserInfo(userId) {
  try {
    const userDoc = await db.collection("users").doc(userId).get()
    return userDoc.exists ? userDoc.data() : null
  } catch (error) {
    console.error("Error fetching user data:", error)
    return null
  }
}

/**
 * Format date to a readable string
 * @param {string} date - Date string
 * @returns {string} Formatted date
 */
function formatDate(date) {
  const options = { year: "numeric", month: "long", day: "numeric" }
  return new Date(date).toLocaleDateString(undefined, options)
}

/**
 * Navigate back to chat
 */
function goBack() {
  window.location.href = "chat.html"
}

/**
 * Handle logout
 */
async function handleLogout() {
  await logoutUser()
}

/**
 * Logout the current user
 */
async function logoutUser() {
  try {
    await auth.signOut()
    window.location.href = "../index.html"
  } catch (error) {
    console.error("Error logging out:", error)
  }
}
