import { db } from "./firebase"
import { ref, get, onValue, type Unsubscribe, update } from "firebase/database"
import type { UserProfile } from "./auth-service"

export const userService = {
  async getUserProfile(userId: string): Promise<UserProfile | null> {
    const snapshot = await get(ref(db, `users/${userId}`))
    return snapshot.val()
  },

  async getAllUsers(): Promise<Record<string, UserProfile>> {
    const snapshot = await get(ref(db, "users"))
    return snapshot.val() || {}
  },

  async searchUsers(searchTerm: string): Promise<UserProfile[]> {
    const allUsers = await this.getAllUsers()
    const searchLower = searchTerm.toLowerCase()

    return Object.values(allUsers).filter((user) => user.name.toLowerCase().includes(searchLower))
  },

  onUsersChanged(callback: (users: Record<string, UserProfile>) => void): Unsubscribe {
    return onValue(ref(db, "users"), (snapshot) => {
      callback(snapshot.val() || {})
    })
  },

  async updateProfileImage(userId: string, imageUrl: string): Promise<void> {
    await update(ref(db, `users/${userId}`), {
      profileImage: imageUrl,
    })
  },

  async updatePrivacyMode(userId: string, isPrivate: boolean): Promise<void> {
    await update(ref(db, `users/${userId}`), {
      isPrivate: isPrivate,
    })
  },

  async updateUsername(userId: string, username: string): Promise<void> {
    await update(ref(db, `users/${userId}`), {
      username: username.toLowerCase().replace(/[^a-z0-9_]/g, ""),
    })
  },
}
