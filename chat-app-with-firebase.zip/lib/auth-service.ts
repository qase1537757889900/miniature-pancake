import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  signInWithPopup,
  GoogleAuthProvider,
  deleteUser,
  updatePassword,
  type User,
} from "firebase/auth"
import { auth, db } from "./firebase"
import { ref, set, update, remove, get } from "firebase/database"

export interface UserProfile {
  uid: string
  name: string
  email: string
  avatar: string
  createdAt: string
  blocked?: Record<string, boolean>
  provider?: string
  profileImage?: string
  username?: string
  bio?: string
  isPrivate?: boolean
}

export const authService = {
  async register(email: string, password: string, name: string): Promise<User> {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password)
    const user = userCredential.user

    const username = name
      .toLowerCase()
      .replace(/[^a-z0-9]/g, "")
      .slice(0, 20)
    const userProfile: UserProfile = {
      uid: user.uid,
      name,
      email,
      avatar: name.charAt(0).toUpperCase(),
      createdAt: new Date().toISOString(),
      blocked: {},
      provider: "email",
      username: username || `user${Math.random().toString(36).slice(2, 9)}`,
      bio: "",
      isPrivate: false,
    }

    await set(ref(db, `users/${user.uid}`), userProfile)
    return user
  },

  async login(email: string, password: string): Promise<User> {
    const userCredential = await signInWithEmailAndPassword(auth, email, password)
    return userCredential.user
  },

  async loginWithGoogle(): Promise<User> {
    const provider = new GoogleAuthProvider()
    const userCredential = await signInWithPopup(auth, provider)
    const user = userCredential.user

    const userRef = ref(db, `users/${user.uid}`)
    const snapshot = await get(userRef)

    if (!snapshot.exists()) {
      const username = (user.displayName || "user")
        .toLowerCase()
        .replace(/[^a-z0-9]/g, "")
        .slice(0, 20)
      const userProfile: UserProfile = {
        uid: user.uid,
        name: user.displayName || "Google User",
        email: user.email || "",
        avatar: (user.displayName || "G").charAt(0).toUpperCase(),
        createdAt: new Date().toISOString(),
        blocked: {},
        provider: "google",
        username: username || `user${Math.random().toString(36).slice(2, 9)}`,
        bio: "",
        isPrivate: false,
      }
      await set(userRef, userProfile)
    }

    return user
  },

  async logout(): Promise<void> {
    await firebaseSignOut(auth)
  },

  async updateUsername(userId: string, newName: string): Promise<void> {
    const newAvatar = newName.charAt(0).toUpperCase()
    await update(ref(db, `users/${userId}`), {
      name: newName,
      avatar: newAvatar,
    })
  },

  async deleteAccount(userId: string): Promise<void> {
    const user = auth.currentUser
    if (!user) throw new Error("لا يوجد مستخدم مسجل دخول")

    try {
      await remove(ref(db, `users/${userId}`))
      await remove(ref(db, `messages`))
      await deleteUser(user)
    } catch (error: any) {
      if (error.code === "auth/requires-recent-login") {
        throw new Error("يجب عليك تسجيل الدخول مرة أخرى لحذف الحساب")
      }
      throw error
    }
  },

  async getAllUserAccounts(): Promise<Record<string, UserProfile>> {
    const snapshot = await get(ref(db, "users"))
    return snapshot.val() || {}
  },

  getCurrentUser(): User | null {
    return auth.currentUser
  },

  async changePassword(newPassword: string): Promise<void> {
    const user = auth.currentUser
    if (!user) throw new Error("لا يوجد مستخدم مسجل دخول")

    try {
      await updatePassword(user, newPassword)
    } catch (error: any) {
      if (error.code === "auth/weak-password") {
        throw new Error("كلمة المرور ضعيفة جداً. استخدم 6 أحرف على الأقل")
      } else if (error.code === "auth/requires-recent-login") {
        throw new Error("يجب عليك تسجيل الدخول مرة أخرى لتغيير كلمة المرور")
      }
      throw error
    }
  },
}
