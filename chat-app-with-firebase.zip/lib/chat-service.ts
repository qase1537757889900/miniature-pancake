import { db } from "./firebase"
import { ref, push, get, onValue, type Unsubscribe, set, remove } from "firebase/database"

export interface Message {
  id?: string
  senderId: string
  senderName: string
  text?: string
  imageUrl?: string
  timestamp: string
}

export interface Chat {
  id: string
  participantIds: [string, string]
  lastMessage: string
  lastMessageTime: string
}

const getChatId = (userId1: string, userId2: string): string => {
  return [userId1, userId2].sort().join("_")
}

export const chatService = {
  async sendMessage(
    userId: string,
    userName: string,
    recipientId: string,
    text: string,
    imageUrl?: string,
  ): Promise<void> {
    const chatId = getChatId(userId, recipientId)
    const messageRef = push(ref(db, `chats/${chatId}/messages`))

    const message: Message = {
      senderId: userId,
      senderName: userName,
      ...(text && { text }),
      ...(imageUrl && { imageUrl }),
      timestamp: new Date().toISOString(),
    }

    await set(messageRef, message)

    // Update last message info
    await set(ref(db, `chats/${chatId}/lastMessage`), text || "صورة")
    await set(ref(db, `chats/${chatId}/lastMessageTime`), new Date().toISOString())
  },

  async getMessages(userId: string, otherUserId: string): Promise<Message[]> {
    const chatId = getChatId(userId, otherUserId)
    const snapshot = await get(ref(db, `chats/${chatId}/messages`))

    if (!snapshot.exists()) return []

    const messages = snapshot.val()
    return Object.entries(messages).map(([id, message]: any) => ({
      id,
      ...message,
    }))
  },

  onMessagesChanged(userId: string, otherUserId: string, callback: (messages: Message[]) => void): Unsubscribe {
    const chatId = getChatId(userId, otherUserId)
    return onValue(ref(db, `chats/${chatId}/messages`), (snapshot) => {
      if (!snapshot.exists()) {
        callback([])
        return
      }

      const messages = snapshot.val()
      const messageList = Object.entries(messages).map(([id, message]: any) => ({
        id,
        ...message,
      }))

      callback(messageList)
    })
  },

  async deleteMessage(userId: string, otherUserId: string, messageId: string): Promise<void> {
    const chatId = getChatId(userId, otherUserId)
    await remove(ref(db, `chats/${chatId}/messages/${messageId}`))
  },

  async deleteAllChats(userId: string): Promise<void> {
    try {
      const chatsSnapshot = await get(ref(db, "chats"))
      if (!chatsSnapshot.exists()) return

      const chats = chatsSnapshot.val()
      const chatsToDelete = []

      for (const [chatId, chat] of Object.entries(chats)) {
        if (chatId.includes(userId)) {
          chatsToDelete.push(chatId)
        }
      }

      for (const chatId of chatsToDelete) {
        await remove(ref(db, `chats/${chatId}`))
      }
    } catch (error) {
      console.error("خطأ في حذف المحادثات:", error)
      throw error
    }
  },

  async deleteSpecificChat(userId: string, otherUserId: string): Promise<void> {
    const chatId = getChatId(userId, otherUserId)
    await remove(ref(db, `chats/${chatId}`))
  },
}
