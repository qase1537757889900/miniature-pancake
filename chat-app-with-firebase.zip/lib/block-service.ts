import { db } from "./firebase"
import { ref, get, update } from "firebase/database"

export const blockService = {
  async blockUser(currentUserId: string, targetUserId: string): Promise<void> {
    const snapshot = await get(ref(db, `users/${currentUserId}`))
    const userData = snapshot.val()
    const blocked = userData?.blocked || {}

    await update(ref(db, `users/${currentUserId}`), {
      blocked: {
        ...blocked,
        [targetUserId]: true,
      },
    })
  },

  async unblockUser(currentUserId: string, targetUserId: string): Promise<void> {
    const snapshot = await get(ref(db, `users/${currentUserId}`))
    const userData = snapshot.val()
    const blocked = userData?.blocked || {}

    delete blocked[targetUserId]
    await update(ref(db, `users/${currentUserId}`), { blocked })
  },

  async getBlockedUsers(userId: string): Promise<Record<string, boolean>> {
    const snapshot = await get(ref(db, `users/${userId}/blocked`))
    return snapshot.val() || {}
  },

  async isUserBlocked(currentUserId: string, targetUserId: string): Promise<boolean> {
    const blocked = await this.getBlockedUsers(currentUserId)
    return blocked[targetUserId] === true
  },
}
