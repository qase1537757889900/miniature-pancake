import { initializeApp } from "firebase/app"
import { getAuth, type Auth } from "firebase/auth"
import { getDatabase, type Database } from "firebase/database"
import { getStorage, type FirebaseStorage } from "firebase/storage"

const firebaseConfig = {
  apiKey: "AIzaSyCfI71Hdjszon8eQNqLS9COroPl4_-OPfM",
  authDomain: "hdhf-2fabe.firebaseapp.com",
  databaseURL: "https://hdhf-2fabe-default-rtdb.firebaseio.com",
  projectId: "hdhf-2fabe",
  storageBucket: "hdhf-2fabe.firebasestorage.app",
  messagingSenderId: "272141168116",
  appId: "1:272141168116:web:666cd5e809e75c05ffdda1",
}

const app = initializeApp(firebaseConfig)
export const auth: Auth = getAuth(app)
export const db: Database = getDatabase(app)
export const storage: FirebaseStorage = getStorage(app)
