import { storage } from "./firebase"
import { ref, uploadBytes, getDownloadURL, deleteObject } from "firebase/storage"

export const storageService = {
  async uploadProfileImage(userId: string, file: File): Promise<string> {
    try {
      const storageRef = ref(storage, `profile-images/${userId}`)
      await uploadBytes(storageRef, file)
      return await getDownloadURL(storageRef)
    } catch (error) {
      console.error("خطأ في رفع الصورة:", error)
      throw error
    }
  },

  async uploadChatImage(userId: string, selectedUserId: string, file: File): Promise<string> {
    try {
      const timestamp = Date.now()
      const storageRef = ref(storage, `chat-images/${userId}-${selectedUserId}/${timestamp}`)
      await uploadBytes(storageRef, file)
      return await getDownloadURL(storageRef)
    } catch (error) {
      console.error("خطأ في رفع الصورة:", error)
      throw error
    }
  },

  async deleteImage(imagePath: string): Promise<void> {
    try {
      const imageRef = ref(storage, imagePath)
      await deleteObject(imageRef)
    } catch (error) {
      console.error("خطأ في حذف الصورة:", error)
    }
  },
}
