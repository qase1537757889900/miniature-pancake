"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { auth, db } from "@/lib/firebase"
import { ChatLayout } from "@/components/chat-layout"
import type { UserProfile } from "@/lib/auth-service"
import { get, ref } from "firebase/database"
import { blockService } from "@/lib/block-service"

export default function ChatPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null)
  const [blockedUsers, setBlockedUsers] = useState<Record<string, boolean>>({})
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(async (authUser) => {
      if (!authUser) {
        router.push("/")
        return
      }

      setUser(authUser)

      // Fetch user profile
      const snapshot = await get(ref(db, `users/${authUser.uid}`))
      if (snapshot.exists()) {
        const profile = snapshot.val()
        setUserProfile(profile)

        // Fetch blocked users
        const blocked = await blockService.getBlockedUsers(authUser.uid)
        setBlockedUsers(blocked)
      }

      setIsLoading(false)
    })

    return () => unsubscribe()
  }, [router])

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-100">
        <div className="text-xl">جاري التحميل...</div>
      </div>
    )
  }

  if (!user || !userProfile) {
    return null
  }

  return <ChatLayout currentUser={user} currentUserProfile={userProfile} blockedUsers={blockedUsers} />
}
