"use client"

import { useEffect, useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { userService } from "@/lib/user-service"
import type { UserProfile } from "@/lib/auth-service"
import { auth } from "@/lib/firebase"
import { ArrowRight, Share2, MessageCircle } from "lucide-react"

export default function PublicProfilePage() {
  const params = useParams()
  const router = useRouter()
  const userId = params.uid as string
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [currentUser, setCurrentUser] = useState(auth.currentUser)
  const [shared, setShared] = useState(false)

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      setCurrentUser(user)
    })
    return () => unsubscribe()
  }, [])

  useEffect(() => {
    const loadProfile = async () => {
      try {
        const profile = await userService.getUserProfile(userId)
        if (profile) {
          setUserProfile(profile)
        }
      } catch (error) {
        console.error("Error loading profile:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadProfile()
  }, [userId])

  const handleShareProfile = async () => {
    if (!userProfile) return
    const shareUrl = `${window.location.origin}/user/${userProfile.uid}`

    try {
      if (navigator.share) {
        await navigator.share({
          title: userProfile.name,
          text: `تفقد ملف شخصي ${userProfile.name}`,
          url: shareUrl,
        })
      } else {
        await navigator.clipboard.writeText(shareUrl)
        setShared(true)
        setTimeout(() => setShared(false), 2000)
      }
    } catch (error) {
      console.error("Error sharing:", error)
    }
  }

  const handleMessageClick = () => {
    if (!currentUser) {
      router.push("/")
      return
    }
    router.push("/chat")
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
        <div className="text-xl dark:text-white">جاري التحميل...</div>
      </div>
    )
  }

  if (!userProfile) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
        <div className="text-xl dark:text-white">المستخدم غير موجود</div>
      </div>
    )
  }

  return (
    <div className="w-full max-w-md mx-auto min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      {/* Header */}
      <div className="sticky top-0 z-20 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-b border-gray-200 dark:border-gray-700 p-4 flex items-center justify-between">
        <button
          onClick={() => router.back()}
          className="text-indigo-600 dark:text-indigo-400 hover:bg-gray-100 dark:hover:bg-gray-700 p-2 rounded-lg transition"
        >
          <ArrowRight size={20} />
        </button>
        <h1 className="text-lg font-bold text-gray-900 dark:text-white">الملف الشخصي</h1>
        <div className="w-8" />
      </div>

      {/* Profile Section */}
      <div className="flex flex-col items-center pt-8 pb-6 px-4">
        {/* Profile Image */}
        <div className="mb-6">
          {userProfile.profileImage ? (
            <img
              src={userProfile.profileImage || "/placeholder.svg"}
              alt={userProfile.name}
              className="w-32 h-32 rounded-full object-cover border-4 border-white dark:border-gray-800 shadow-2xl"
            />
          ) : (
            <div className="w-32 h-32 rounded-full bg-gradient-to-br from-blue-500 via-indigo-500 to-purple-500 flex items-center justify-center text-white text-5xl font-bold border-4 border-white dark:border-gray-800 shadow-2xl">
              {userProfile.avatar}
            </div>
          )}
        </div>

        {/* Name */}
        <h2 className="text-3xl font-bold text-gray-900 dark:text-white text-center mb-2">{userProfile.name}</h2>

        {/* Username */}
        <p className="text-indigo-600 dark:text-indigo-400 font-semibold text-lg mb-4">
          @{userProfile.username || "username"}
        </p>

        {/* Bio */}
        {userProfile.bio && (
          <p className="text-gray-600 dark:text-gray-400 text-center text-sm mb-6 max-w-xs">{userProfile.bio}</p>
        )}

        {/* Action Buttons */}
        {currentUser && currentUser.uid !== userProfile.uid && (
          <div className="flex gap-3 w-full px-4">
            <button
              onClick={handleMessageClick}
              className="flex-1 bg-indigo-600 dark:bg-indigo-600 text-white py-3 rounded-xl font-semibold hover:bg-indigo-700 dark:hover:bg-indigo-700 transition flex items-center justify-center gap-2 shadow-lg"
            >
              <MessageCircle size={18} />
              رسالة
            </button>
            <button
              onClick={handleShareProfile}
              className={`flex-1 py-3 rounded-xl font-semibold transition border-2 flex items-center justify-center gap-2 ${
                shared
                  ? "bg-green-50 dark:bg-green-900/20 border-green-500 text-green-600 dark:text-green-400"
                  : "bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700"
              } shadow-lg`}
            >
              <Share2 size={18} />
              {shared ? "تم" : "شارك"}
            </button>
          </div>
        )}
      </div>

      {/* User Info Section */}
      <div className="px-4 space-y-4 pb-8">
        {/* Email */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-4 border border-gray-200 dark:border-gray-700">
          <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 mb-2">البريد الإلكتروني</p>
          <p className="text-gray-900 dark:text-white font-semibold break-all">{userProfile.email}</p>
        </div>

        {/* Join Date */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-4 border border-gray-200 dark:border-gray-700">
          <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 mb-2">تاريخ الانضمام</p>
          <p className="text-gray-900 dark:text-white font-semibold">
            {new Date(userProfile.createdAt).toLocaleDateString("ar-SA")}
          </p>
        </div>

        {/* Provider */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-4 border border-gray-200 dark:border-gray-700">
          <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 mb-2">طريقة الدخول</p>
          <p className="text-gray-900 dark:text-white font-semibold">
            {userProfile.provider === "google" ? "Google" : "البريد الإلكتروني"}
          </p>
        </div>
      </div>
    </div>
  )
}
