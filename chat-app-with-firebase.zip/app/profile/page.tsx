"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { auth, db } from "@/lib/firebase"
import type { UserProfile } from "@/lib/auth-service"
import { authService } from "@/lib/auth-service"
import { blockService } from "@/lib/block-service"
import { userService } from "@/lib/user-service"
import { storageService } from "@/lib/storage-service"
import { get, ref } from "firebase/database"
import { ArrowRight, LogOut, Lock, Trash2, AlertCircle, Key, Upload } from "lucide-react"

export default function ProfilePage() {
  const router = useRouter()
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isEditingName, setIsEditingName] = useState(false)
  const [newName, setNewName] = useState("")
  const [isSaving, setIsSaving] = useState(false)
  const [blockedUsers, setBlockedUsers] = useState<UserProfile[]>([])
  const [allUsers, setAllUsers] = useState<Record<string, UserProfile>>({})
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)
  const [allAccounts, setAllAccounts] = useState<UserProfile[]>([])
  const [isEditingPassword, setIsEditingPassword] = useState(false)
  const [currentPassword, setCurrentPassword] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [passwordError, setPasswordError] = useState("")
  const [isUploadingImage, setIsUploadingImage] = useState(false)
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [isPrivate, setIsPrivate] = useState(false)

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(async (user) => {
      if (!user) {
        router.push("/")
        return
      }

      const snapshot = await get(ref(db, `users/${user.uid}`))
      if (snapshot.exists()) {
        const profile = snapshot.val() as UserProfile
        setUserProfile(profile)
        setNewName(profile.name)
        setIsPrivate(profile.isPrivate || false)

        const blocked = profile.blocked || {}
        const usersSnapshot = await userService.getAllUsers()
        setAllUsers(usersSnapshot)

        const blockedUsersList = Object.entries(blocked)
          .filter(([_, isBlocked]) => isBlocked)
          .map(([userId]) => usersSnapshot[userId])
          .filter(Boolean)

        setBlockedUsers(blockedUsersList)

        const accounts = Object.values(usersSnapshot).filter((u) => u.uid !== user.uid)
        setAllAccounts(accounts)
      }

      setIsLoading(false)
    })

    return () => unsubscribe()
  }, [router])

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file || !userProfile) return

    setIsUploadingImage(true)
    try {
      const imageUrl = await storageService.uploadProfileImage(userProfile.uid, file)
      await userService.updateProfileImage(userProfile.uid, imageUrl)
      setUserProfile({ ...userProfile, profileImage: imageUrl })
    } catch (error) {
      console.error("خطأ في رفع الصورة:", error)
      alert("حدث خطأ في رفع الصورة")
    } finally {
      setIsUploadingImage(false)
    }
  }

  const handleUpdateName = async () => {
    if (!newName.trim() || !userProfile) return

    setIsSaving(true)
    try {
      await authService.updateUsername(userProfile.uid, newName.trim())
      setUserProfile({ ...userProfile, name: newName.trim(), avatar: newName.charAt(0).toUpperCase() })
      setIsEditingName(false)
    } catch (error) {
      console.error("خطأ في تحديث الاسم:", error)
      setNewName(userProfile.name)
    } finally {
      setIsSaving(false)
    }
  }

  const handleChangePassword = async () => {
    setPasswordError("")

    if (!newPassword || !confirmPassword) {
      setPasswordError("يرجى ملء جميع الحقول")
      return
    }

    if (newPassword !== confirmPassword) {
      setPasswordError("كلمات المرور غير متطابقة")
      return
    }

    if (newPassword.length < 6) {
      setPasswordError("كلمة المرور يجب أن تكون 6 أحرف على الأقل")
      return
    }

    setIsSaving(true)
    try {
      await authService.changePassword(newPassword)
      setIsEditingPassword(false)
      setCurrentPassword("")
      setNewPassword("")
      setConfirmPassword("")
      alert("تم تغيير كلمة المرور بنجاح")
    } catch (error: any) {
      setPasswordError(error.message || "حدث خطأ في تغيير كلمة المرور")
    } finally {
      setIsSaving(false)
    }
  }

  const handleUnblockUser = async (blockedUserId: string) => {
    if (!userProfile) return

    try {
      await blockService.unblockUser(userProfile.uid, blockedUserId)
      setBlockedUsers(blockedUsers.filter((u) => u.uid !== blockedUserId))
    } catch (error) {
      console.error("خطأ في فك الحظر:", error)
    }
  }

  const handleUpdatePrivacy = async (isPrivate: boolean) => {
    if (!userProfile) return

    try {
      await userService.updatePrivacyMode(userProfile.uid, isPrivate)
      setIsPrivate(isPrivate)
      setUserProfile({ ...userProfile, isPrivate: isPrivate })
    } catch (error) {
      console.error("خطأ في تحديث الخصوصية:", error)
    }
  }

  const handleToggleDarkMode = () => {
    const newDarkMode = !isDarkMode
    setIsDarkMode(newDarkMode)
    if (newDarkMode) {
      document.documentElement.classList.add("dark")
      localStorage.setItem("darkMode", "true")
    } else {
      document.documentElement.classList.remove("dark")
      localStorage.setItem("darkMode", "false")
    }
  }

  const handleDeleteAccount = async () => {
    if (!userProfile) return

    setIsSaving(true)
    try {
      await authService.deleteAccount(userProfile.uid)
      router.push("/")
    } catch (error: any) {
      console.error("خطأ في حذف الحساب:", error)
      alert(error.message || "حدث خطأ في حذف الحساب")
    } finally {
      setIsSaving(false)
    }
  }

  const handleLogout = async () => {
    try {
      await auth.signOut()
      router.push("/")
    } catch (error) {
      console.error("خطأ في تسجيل الخروج:", error)
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-100 dark:bg-gray-900">
        <div className="text-xl dark:text-white">جاري التحميل...</div>
      </div>
    )
  }

  if (!userProfile) {
    return null
  }

  return (
    <div className="h-screen w-full max-w-md mx-auto bg-white dark:bg-gray-900 flex flex-col overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-gray-200 dark:border-gray-700 bg-gradient-to-r from-indigo-600 to-purple-600 text-white sticky top-0 z-20">
        <button
          onClick={() => router.back()}
          className="flex items-center gap-2 text-white hover:bg-white/20 p-2 rounded-lg transition"
        >
          <ArrowRight size={20} />
          <span className="text-sm font-medium">العودة</span>
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* Profile Section with Image Upload */}
        <div className="bg-gradient-to-br from-indigo-50 dark:from-indigo-900/20 to-purple-50 dark:to-purple-900/20 rounded-lg p-6 text-center">
          <div className="relative inline-block">
            {userProfile.profileImage ? (
              <img
                src={userProfile.profileImage || "/placeholder.svg"}
                alt={userProfile.name}
                className="w-20 h-20 rounded-full object-cover border-4 border-white dark:border-gray-800 shadow-lg"
              />
            ) : (
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center text-white text-3xl font-bold border-4 border-white dark:border-gray-800 shadow-lg">
                {userProfile.avatar}
              </div>
            )}
            {/* Image Upload Button */}
            <label className="absolute bottom-0 right-0 bg-indigo-600 hover:bg-indigo-700 text-white p-2 rounded-full cursor-pointer transition shadow-lg">
              <Upload size={14} />
              <input
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                disabled={isUploadingImage}
                className="hidden"
              />
            </label>
          </div>
        </div>

        {/* Name Section */}
        <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-4">
          <h3 className="text-sm font-semibold text-gray-600 dark:text-gray-400 mb-3">اسم المستخدم</h3>
          {isEditingName ? (
            <div className="space-y-3">
              <input
                type="text"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="اسم المستخدم الجديد"
                className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:border-indigo-600 dark:focus:border-indigo-400 text-sm dark:bg-gray-700 dark:text-white"
                maxLength={30}
              />
              <div className="flex gap-2">
                <button
                  onClick={handleUpdateName}
                  disabled={isSaving || !newName.trim() || newName === userProfile.name}
                  className="flex-1 bg-indigo-600 dark:bg-indigo-600 text-white py-2 rounded-lg text-sm font-medium hover:bg-indigo-700 dark:hover:bg-indigo-700 transition disabled:opacity-50"
                >
                  {isSaving ? "جاري الحفظ..." : "حفظ"}
                </button>
                <button
                  onClick={() => {
                    setIsEditingName(false)
                    setNewName(userProfile.name)
                  }}
                  className="flex-1 bg-gray-200 dark:bg-gray-700 text-gray-900 dark:text-white py-2 rounded-lg text-sm font-medium hover:bg-gray-300 dark:hover:bg-gray-600 transition"
                >
                  إلغاء
                </button>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-between">
              <span className="text-gray-900 dark:text-white font-semibold">{userProfile.name}</span>
              <button
                onClick={() => setIsEditingName(true)}
                className="text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 px-3 py-1 rounded-lg text-sm font-medium transition"
              >
                تعديل
              </button>
            </div>
          )}
        </div>

        {/* Email Section */}
        <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-4">
          <h3 className="text-sm font-semibold text-gray-600 dark:text-gray-400 mb-2">البريد الإلكتروني</h3>
          <p className="text-gray-900 dark:text-white font-semibold break-all">{userProfile.email}</p>
        </div>

        {/* Join Date Section */}
        <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-4">
          <h3 className="text-sm font-semibold text-gray-600 dark:text-gray-400 mb-2">تاريخ الانضمام</h3>
          <p className="text-gray-900 dark:text-white font-semibold">
            {new Date(userProfile.createdAt).toLocaleDateString("ar-SA")}
          </p>
        </div>

        {/* Provider Info */}
        <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-4">
          <h3 className="text-sm font-semibold text-gray-600 dark:text-gray-400 mb-2">طريقة الدخول</h3>
          <p className="text-gray-900 dark:text-white font-semibold">
            {userProfile.provider === "google" ? "تسجيل دخول عبر Google" : "البريد الإلكتروني وكلمة المرور"}
          </p>
        </div>

        {/* Privacy Section */}
        <div className="bg-white dark:bg-gray-800 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
          <h3 className="text-sm font-semibold text-blue-600 dark:text-blue-400 mb-3">الخصوصية</h3>
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium text-gray-700 dark:text-gray-300">الملف الشخصي خاص</label>
            <button
              onClick={() => handleUpdatePrivacy(!isPrivate)}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition ${
                isPrivate ? "bg-blue-600" : "bg-gray-300 dark:bg-gray-600"
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition ${
                  isPrivate ? "translate-x-6" : "translate-x-1"
                }`}
              />
            </button>
          </div>
        </div>

        {/* Dark Mode Section */}
        <div className="bg-white dark:bg-gray-800 border border-purple-200 dark:border-purple-800 rounded-lg p-4">
          <h3 className="text-sm font-semibold text-purple-600 dark:text-purple-400 mb-3">المظهر</h3>
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium text-gray-700 dark:text-gray-300">الوضع الليلي</label>
            <button
              onClick={handleToggleDarkMode}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition ${
                isDarkMode ? "bg-purple-600" : "bg-gray-300 dark:bg-gray-600"
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition ${
                  isDarkMode ? "translate-x-6" : "translate-x-1"
                }`}
              />
            </button>
          </div>
        </div>

        {/* Change Password Section */}
        {userProfile.provider !== "google" && (
          <div className="bg-white dark:bg-gray-800 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
            <h3 className="text-sm font-semibold text-blue-600 dark:text-blue-400 mb-3 flex items-center gap-2">
              <Key size={16} />
              تغيير كلمة المرور
            </h3>
            {isEditingPassword ? (
              <div className="space-y-3">
                <input
                  type="password"
                  placeholder="كلمة المرور الجديدة"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:border-blue-600 dark:focus:border-blue-400 text-sm dark:bg-gray-700 dark:text-white"
                />
                <input
                  type="password"
                  placeholder="تأكيد كلمة المرور"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:border-blue-600 dark:focus:border-blue-400 text-sm dark:bg-gray-700 dark:text-white"
                />
                {passwordError && <p className="text-red-600 dark:text-red-400 text-xs">{passwordError}</p>}
                <div className="flex gap-2">
                  <button
                    onClick={handleChangePassword}
                    disabled={isSaving || !newPassword || !confirmPassword}
                    className="flex-1 bg-blue-600 dark:bg-blue-600 text-white py-2 rounded-lg text-sm font-medium hover:bg-blue-700 dark:hover:bg-blue-700 transition disabled:opacity-50"
                  >
                    {isSaving ? "جاري التحديث..." : "تحديث"}
                  </button>
                  <button
                    onClick={() => {
                      setIsEditingPassword(false)
                      setNewPassword("")
                      setConfirmPassword("")
                      setPasswordError("")
                    }}
                    className="flex-1 bg-gray-200 dark:bg-gray-700 text-gray-900 dark:text-white py-2 rounded-lg text-sm font-medium hover:bg-gray-300 dark:hover:bg-gray-600 transition"
                  >
                    إلغاء
                  </button>
                </div>
              </div>
            ) : (
              <button
                onClick={() => setIsEditingPassword(true)}
                className="w-full text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20 py-2 rounded-lg text-sm font-medium transition"
              >
                تغيير كلمة المرور
              </button>
            )}
          </div>
        )}

        {/* Blocked Users Section */}
        {blockedUsers.length > 0 && (
          <div className="bg-white dark:bg-gray-800 border border-red-200 dark:border-red-800 rounded-lg p-4">
            <h3 className="text-sm font-semibold text-red-600 dark:text-red-400 mb-3 flex items-center gap-2">
              <Lock size={16} />
              المستخدمون المحظورون ({blockedUsers.length})
            </h3>
            <div className="space-y-2">
              {blockedUsers.map((user) => (
                <div
                  key={user.uid}
                  className="flex items-center justify-between bg-red-50 dark:bg-red-900/20 p-3 rounded-lg"
                >
                  <div className="flex items-center gap-2 flex-1 min-w-0">
                    {user.profileImage ? (
                      <img
                        src={user.profileImage || "/placeholder.svg"}
                        alt={user.name}
                        className="w-8 h-8 rounded-full object-cover flex-shrink-0"
                      />
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-600 to-purple-600 text-white flex items-center justify-center font-bold flex-shrink-0 text-xs">
                        {user.avatar}
                      </div>
                    )}
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold text-gray-900 dark:text-white">{user.name}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => handleUnblockUser(user.uid)}
                    className="text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 px-2 py-1 rounded text-xs font-medium transition"
                  >
                    انتقل
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Danger Zone */}
        <div className="bg-white dark:bg-gray-800 border border-red-200 dark:border-red-800 rounded-lg p-4">
          <h3 className="text-sm font-semibold text-red-600 dark:text-red-400 mb-3 flex items-center gap-2">
            <AlertCircle size={16} />
            منطقة الخطر
          </h3>
          <button
            onClick={() => setShowDeleteConfirm(true)}
            className="w-full bg-red-50 dark:bg-red-900/20 border border-red-300 dark:border-red-800 text-red-600 dark:text-red-400 py-2 rounded-lg text-sm font-medium hover:bg-red-100 dark:hover:bg-red-900/40 transition flex items-center justify-center gap-2"
          >
            <Trash2 size={16} />
            حذف الحساب نهائياً
          </button>
        </div>

        {showDeleteConfirm && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <div className="bg-white dark:bg-gray-800 rounded-lg p-6 max-w-sm w-full">
              <h3 className="text-lg font-bold text-red-600 dark:text-red-400 mb-2">تحذير</h3>
              <p className="text-gray-600 dark:text-gray-400 mb-4 text-sm">
                هذا الإجراء لا يمكن التراجع عنه. سيتم حذف حسابك وجميع بيانات رسائلك بشكل دائم.
              </p>
              <div className="flex gap-3">
                <button
                  onClick={() => setShowDeleteConfirm(false)}
                  className="flex-1 bg-gray-200 dark:bg-gray-700 text-gray-900 dark:text-white py-2 rounded-lg font-medium hover:bg-gray-300 dark:hover:bg-gray-600 transition"
                >
                  إلغاء
                </button>
                <button
                  onClick={handleDeleteAccount}
                  disabled={isSaving}
                  className="flex-1 bg-red-600 dark:bg-red-600 text-white py-2 rounded-lg font-medium hover:bg-red-700 dark:hover:bg-red-700 transition disabled:opacity-50"
                >
                  {isSaving ? "جاري..." : "حذف"}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Logout Button */}
      <div className="p-4 border-t border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800">
        <button
          onClick={handleLogout}
          className="w-full bg-red-600 dark:bg-red-600 text-white py-3 rounded-lg font-semibold hover:bg-red-700 dark:hover:bg-red-700 transition flex items-center justify-center gap-2"
        >
          <LogOut size={18} />
          تسجيل الخروج
        </button>
      </div>
    </div>
  )
}
