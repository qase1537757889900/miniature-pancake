// DOM Helper Functions

/**
 * Show element
 * @param {HTMLElement} element - Element to show
 */
function show(element) {
  element?.classList.remove("hidden")
}

/**
 * Hide element
 * @param {HTMLElement} element - Element to hide
 */
function hide(element) {
  element?.classList.add("hidden")
}

/**
 * Toggle element visibility
 * @param {HTMLElement} element - Element to toggle
 */
function toggle(element) {
  element?.classList.toggle("hidden")
}

/**
 * Get element by ID
 * @param {string} id - Element ID
 * @returns {HTMLElement} - Element
 */
function getEl(id) {
  return document.getElementById(id)
}

/**
 * Create element with class
 * @param {string} tag - Tag name
 * @param {string} className - Class name
 * @param {string} content - Inner content
 * @returns {HTMLElement} - Created element
 */
function createElement(tag, className = "", content = "") {
  const el = document.createElement(tag)
  if (className) el.className = className
  if (content) el.innerHTML = content
  return el
}

/**
 * Show error message
 * @param {string} elementId - Error element ID
 * @param {string} message - Error message
 */
function showError(elementId, message) {
  const errorEl = getEl(elementId)
  if (errorEl) {
    errorEl.textContent = message
    show(errorEl)
  }
}

/**
 * Clear error message
 * @param {string} elementId - Error element ID
 */
function clearError(elementId) {
  const errorEl = getEl(elementId)
  if (errorEl) {
    errorEl.textContent = ""
    hide(errorEl)
  }
}

export { show, hide, toggle, getEl, createElement, showError, clearError }
