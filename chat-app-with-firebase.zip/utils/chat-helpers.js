// Chat Helper Functions
import { database } from "./firebase-config" // Assuming Firebase is used for database operations

/**
 * Generate unique chat ID from two user IDs
 * @param {string} user1Id - First user ID
 * @param {string} user2Id - Second user ID
 * @returns {string} - Unique chat ID
 */
function getChatId(user1Id, user2Id) {
  return [user1Id, user2Id].sort().join("_")
}

/**
 * Escape HTML to prevent XSS
 * @param {string} text - Text to escape
 * @returns {string} - Escaped HTML
 */
function escapeHtml(text) {
  const div = document.createElement("div")
  div.textContent = text
  return div.innerHTML
}

/**
 * Format message timestamp
 * @param {string} timestamp - ISO timestamp
 * @returns {string} - Formatted time
 */
function formatTime(timestamp) {
  const date = new Date(timestamp)
  return date.toLocaleTimeString("ar-SA", { hour: "2-digit", minute: "2-digit" })
}

/**
 * Format date
 * @param {string} timestamp - ISO timestamp
 * @returns {string} - Formatted date
 */
function formatDate(timestamp) {
  const date = new Date(timestamp)
  return date.toLocaleDateString("ar-SA")
}

/**
 * Send message to database
 * @param {string} senderId - Sender user ID
 * @param {string} recipientId - Recipient user ID
 * @param {string} text - Message text
 */
async function sendMessage(senderId, recipientId, text) {
  if (!text.trim()) return { success: false }

  const chatId = getChatId(senderId, recipientId)
  const messageId = database.ref(`messages/${chatId}`).push().key

  try {
    await database.ref(`messages/${chatId}/${messageId}`).set({
      text: text.trim(),
      senderId: senderId,
      timestamp: new Date().toISOString(),
    })
    return { success: true, messageId }
  } catch (error) {
    console.error("Error sending message:", error)
    return { success: false, error }
  }
}

/**
 * Load all messages for a chat
 * @param {string} user1Id - First user ID
 * @param {string} user2Id - Second user ID
 */
async function loadMessages(user1Id, user2Id) {
  const chatId = getChatId(user1Id, user2Id)

  try {
    const snapshot = await database.ref(`messages/${chatId}`).once("value")
    const messages = snapshot.val() || {}
    return Object.entries(messages).map(([id, data]) => ({ id, ...data }))
  } catch (error) {
    console.error("Error loading messages:", error)
    return []
  }
}

/**
 * Load all users
 */
async function loadAllUsers() {
  try {
    const snapshot = await database.ref("users").once("value")
    return snapshot.val() || {}
  } catch (error) {
    console.error("Error loading users:", error)
    return {}
  }
}

/**
 * Search users by name or email
 * @param {object} users - Users object
 * @param {string} query - Search query
 * @param {string} excludeUserId - User ID to exclude
 */
function searchUsers(users, query, excludeUserId) {
  const lowerQuery = query.toLowerCase()
  return Object.entries(users).filter(([userId, userData]) => {
    return (
      userId !== excludeUserId &&
      (userData.name.toLowerCase().includes(lowerQuery) || userData.email.toLowerCase().includes(lowerQuery))
    )
  })
}

export { getChatId, escapeHtml, formatTime, formatDate, sendMessage, loadMessages, loadAllUsers, searchUsers }
