// Authentication Helper Functions
import { auth, database } from "./firebase-config" // Assuming auth and database are imported from firebase-config

/**
 * Get error message based on Firebase error code
 * @param {string} code - Firebase error code
 * @returns {string} - User-friendly error message
 */
function getErrorMessage(code) {
  const messages = {
    "auth/email-already-in-use": "البريد الإلكتروني مستخدم بالفعل",
    "auth/weak-password": "كلمة المرور ضعيفة جداً (يجب أن تكون 6 أحرف على الأقل)",
    "auth/user-not-found": "المستخدم غير موجود",
    "auth/wrong-password": "كلمة المرور خاطئة",
    "auth/invalid-email": "البريد الإلكتروني غير صحيح",
    "auth/operation-not-allowed": "هذه العملية غير متاحة حالياً",
  }
  return messages[code] || "حدث خطأ ما. حاول مرة أخرى"
}

/**
 * Register new user
 * @param {string} name - User name
 * @param {string} email - User email
 * @param {string} password - User password
 */
async function registerUser(name, email, password) {
  try {
    const userCredential = await auth.createUserWithEmailAndPassword(email, password)
    const userId = userCredential.user.uid

    // Save user data to database
    await database.ref("users/" + userId).set({
      name: name,
      email: email,
      createdAt: new Date().toISOString(),
      avatar: name.charAt(0).toUpperCase(),
      uid: userId,
    })

    return { success: true, userId }
  } catch (error) {
    return { success: false, error: getErrorMessage(error.code) }
  }
}

/**
 * Login user
 * @param {string} email - User email
 * @param {string} password - User password
 */
async function loginUser(email, password) {
  try {
    await auth.signInWithEmailAndPassword(email, password)
    return { success: true }
  } catch (error) {
    return { success: false, error: getErrorMessage(error.code) }
  }
}

/**
 * Logout user
 */
async function logoutUser() {
  try {
    await auth.signOut()
    window.location.href = "../index.html"
  } catch (error) {
    console.error("Logout error:", error)
  }
}

/**
 * Get current user info
 */
async function getCurrentUserInfo() {
  try {
    const snapshot = await database.ref(`users/${auth.currentUser.uid}`).once("value")
    return snapshot.val()
  } catch (error) {
    console.error("Error loading user info:", error)
    return null
  }
}

export { getErrorMessage, registerUser, loginUser, logoutUser, getCurrentUserInfo }
