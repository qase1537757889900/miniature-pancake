# هيكل المشروع

## هيكل الملفات

\`\`\`
chatapp/
├── index.html                 # صفحة التسجيل والدخول
├── config/
│   ├── firebase-config.js     # إعدادات Firebase
│   └── constants.js           # ثوابت التطبيق
├── pages/
│   ├── chat.html             # صفحة الدردشة الرئيسية
│   └── profile.html          # صفحة الملف الشخصي
├── js/
│   ├── auth.js               # منطق صفحة المصادقة
│   ├── chat.js               # منطق صفحة الدردشة
│   ├── profile.js            # منطق صفحة الملف الشخصي
│   ├── auth-service.js       # خدمة المصادقة
│   ├── user-service.js       # خدمة المستخدمين
│   ├── message-service.js    # خدمة الرسائل
│   ├── validation.js         # خدمة التحقق من البيانات
│   ├── ui-helpers.js         # مساعدات الواجهة
│   ├── logger.js             # خدمة السجل
│   └── storage.js            # خدمة التخزين المحلي
├── styles/
│   ├── global.css            # الأنماط العامة
│   ├── variables.css         # متغيرات CSS
│   ├── auth.css              # أنماط المصادقة
│   ├── chat.css              # أنماط الدردشة
│   ├── profile.css           # أنماط الملف الشخصي
│   ├── buttons.css           # أنماط الأزرار
│   ├── forms.css             # أنماط النماذج
│   ├── cards.css             # أنماط البطاقات
│   ├── messages.css          # أنماط الرسائل
│   └── layout.css            # أنماط التخطيط
├── docs/
│   ├── INSTALLATION.md       # دليل التثبيت
│   └── STRUCTURE.md          # هذا الملف
└── README.md                 # ملف التعريف الرئيسي
\`\`\`

## وصف الملفات الرئيسية

### صفحات HTML
- **index.html** - صفحة التسجيل والدخول
- **pages/chat.html** - واجهة الدردشة الرئيسية
- **pages/profile.html** - صفحة ملف المستخدم

### خدمات JavaScript
- **auth-service.js** - التسجيل والدخول والتحقق
- **user-service.js** - إدارة بيانات المستخدمين
- **message-service.js** - إرسال واستقبال الرسائل
- **validation.js** - التحقق من صحة البيانات

### أنماط CSS
- **variables.css** - الألوان والفراغات والظلال
- **auth.css** - تصميم صفحة المصادقة
- **chat.css** - تصميم صفحة الدردشة
- **buttons.css** - تصاميم الأزرار المختلفة
- **forms.css** - تصاميم النماذج المختلفة

## دورة حياة التطبيق

1. **التحميل الأولي**
   - تحميل Firebase
   - التحقق من حالة المستخدم

2. **المصادقة**
   - إنشاء حساب أو تسجيل دخول
   - حفظ بيانات المستخدم

3. **الدردشة**
   - تحميل قائمة المستخدمين
   - البحث عن المستخدمين
   - إرسال واستقبال الرسائل

4. **الملف الشخصي**
   - عرض بيانات المستخدم
   - تسجيل الخروج

## نماذج البيانات

### بيانات المستخدم
\`\`\`javascript
{
  uid: "user-id",
  name: "اسم المستخدم",
  email: "email@example.com",
  avatar: "M",
  createdAt: "2024-01-01T00:00:00Z",
  status: "online"
}
\`\`\`

### بيانات الرسالة
\`\`\`javascript
{
  id: "message-id",
  text: "محتوى الرسالة",
  senderId: "sender-id",
  timestamp: "2024-01-01T00:00:00Z"
}
\`\`\`
\`\`\`
