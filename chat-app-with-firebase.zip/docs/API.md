# توثيق الـ API والخدمات

## خدمة المصادقة (auth-service.js)

### registerUser(name, email, password)
إنشاء حساب مستخدم جديد

**المدخلات:**
- name (string) - اسم المستخدم
- email (string) - البريد الإلكتروني
- password (string) - كلمة المرور

**المخرجات:**
\`\`\`javascript
{
  success: boolean,
  userId?: string,
  error?: string
}
\`\`\`

### loginUser(email, password)
تسجيل دخول المستخدم

**المدخلات:**
- email (string) - البريد الإلكتروني
- password (string) - كلمة المرور

### logoutUser()
تسجيل خروج المستخدم

### getCurrentUser()
الحصول على بيانات المستخدم الحالي

---

## خدمة الرسائل (message-service.js)

### sendMessage(senderId, recipientId, text)
إرسال رسالة

**المدخلات:**
- senderId (string) - معرف المرسل
- recipientId (string) - معرف المستقبل
- text (string) - نص الرسالة

### loadMessages(user1Id, user2Id)
تحميل الرسائل بين مستخدمين

**المخرجات:**
\`\`\`javascript
[
  {
    id: "message-id",
    text: "محتوى الرسالة",
    senderId: "sender-id",
    timestamp: "2024-01-01T00:00:00Z"
  }
]
\`\`\`

### listenToMessages(user1Id, user2Id, callback)
الاستماع للرسائل في الوقت الفعلي

---

## خدمة المستخدمين (user-service.js)

### loadAllUsers()
تحميل قائمة جميع المستخدمين

### searchUsers(users, query, excludeUserId)
البحث عن مستخدمين

**المدخلات:**
- users (object) - كائن المستخدمين
- query (string) - نص البحث
- excludeUserId (string) - معرف المستخدم المستثنى

---

## خدمة التحقق (validation.js)

### validateEmail(email)
التحقق من صحة البريد الإلكتروني

### validatePassword(password)
التحقق من قوة كلمة المرور

### validateUsername(name)
التحقق من اسم المستخدم

### validateMessage(message)
التحقق من نص الرسالة

---

## مساعدات الواجهة (ui-helpers.js)

### show(element)
عرض عنصر

### hide(element)
إخفاء عنصر

### toggle(element)
تبديل حالة العنصر

### getEl(id)
الحصول على عنصر بواسطة المعرف

### escapeHtml(text)
تجنب حقن الأكواد الضارة

\`\`\`
