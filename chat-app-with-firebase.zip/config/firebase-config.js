// Firebase Configuration and Initialization

// Import Firebase module
import firebase from "firebase/app"
import "firebase/auth"
import "firebase/database"

const firebaseConfig = {
  apiKey: "AIzaSyCfI71Hdjszon8eQNqLS9COroPl4_-OPfM",
  authDomain: "hdhf-2fabe.firebaseapp.com",
  databaseURL: "https://hdhf-2fabe-default-rtdb.firebaseio.com",
  projectId: "hdhf-2fabe",
  storageBucket: "hdhf-2fabe.firebasestorage.app",
  messagingSenderId: "272141168116",
  appId: "1:272141168116:web:666cd5e809e75c05ffdda1",
}

// Initialize Firebase
firebase.initializeApp(firebaseConfig)

// Get references to Firebase services
const auth = firebase.auth()
const database = firebase.database()

// Auth state listener - Redirect based on authentication status
auth.onAuthStateChanged((user) => {
  const currentPath = window.location.pathname
  const isAuthPage = currentPath.includes("index.html") || currentPath === "/"

  if (user && isAuthPage) {
    // User is logged in but on auth page, redirect to chat
    window.location.href = "pages/chat.html"
  } else if (!user && !isAuthPage) {
    // User is not logged in but not on auth page, redirect to login
    window.location.href = "../index.html"
  }
})

// Export for use in other modules
export { auth, database }
