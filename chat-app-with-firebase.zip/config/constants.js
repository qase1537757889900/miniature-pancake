// Application Constants

export const APP_CONFIG = {
  name: "ChatApp",
  version: "1.0.0",
  lang: "ar",
  direction: "rtl",
  theme: "light",
  debug: false,
}

export const API_ENDPOINTS = {
  users: "/users",
  messages: "/messages",
  auth: "/auth",
  profile: "/profile",
}

export const MESSAGE_LIMITS = {
  minLength: 1,
  maxLength: 5000,
}

export const USER_LIMITS = {
  minNameLength: 2,
  maxNameLength: 50,
}

export const TIMING = {
  messageRefreshInterval: 1000, // ms
  debounceDelay: 300, // ms
  animationDuration: 300, // ms
}

export const ERROR_MESSAGES = {
  networkError: "خطأ في الاتصال بالإنترنت",
  unknownError: "حدث خطأ غير متوقع",
  emptyMessage: "الرسالة فارغة",
  invalidEmail: "البريد الإلكتروني غير صحيح",
  unauthorizedError: "ليس لديك صلاحيات كافية",
}

export const SUCCESS_MESSAGES = {
  loginSuccess: "تم تسجيل الدخول بنجاح",
  registerSuccess: "تم إنشاء الحساب بنجاح",
  logoutSuccess: "تم تسجيل الخروج بنجاح",
  messageSent: "تم إرسال الرسالة",
  profileUpdated: "تم تحديث الملف الشخصي",
}
